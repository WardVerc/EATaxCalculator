package sample;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class Main extends Application {
    //hier kunt ge dingen instantieren

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage window) throws Exception {
        //vanaf hier kunt ge uw code beginnen typen om een javafx-applicatie te maken, al hetgeen hierboven is nodig om een GUI te maken
        //de "stage" is uw window, bovenste balk met kruisje, minimalize, maximize
        // de "scene" is al hetgene in uw 'stage', al uw elementen zoals knoppen, inputfields enzo

        window.setTitle("EA Tax Calculator - It's not in the game"); //titel van uw nieuwe window of 'stage', deze titel verschijnt in de bovenste balk van de window

        GridPane layout = new GridPane(); //is een standaard soort layout, zorgt voor een denkbeeldig raster
        layout.setPadding(new Insets(10, 10, 10, 10)); //zorgt dat uw elementen niet tegen de rand van uw window plakken
        layout.setVgap(8); //zorgt dat er plaats is verticaal tussen uw elementen
        layout.setHgap(10); //horizontaal

        Label labelAankoop = new Label("Aankoopprijs: "); //gewone tekst
        GridPane.setConstraints(labelAankoop, 0, 1); //dit plaats labelAankoop in de eerste kolom en in de 2de rij

        TextField textfield = new TextField(); //een input veldje waar de user tekst in kan typen, zoals bij een login
        GridPane.setConstraints(textfield, 1, 1);

        Label labelVerkoop = new Label("Verkoopprijs: "); //noch einmahl
        GridPane.setConstraints(labelVerkoop, 0, 2);

        TextField textfield2 = new TextField();
        GridPane.setConstraints(textfield2, 1, 2);

        Button knopje1 = new Button(); //nieuwe knop aanmaken
        knopje1.setText("Calculate tax"); //zet er tekst in (doe je best altijd)
        GridPane.setConstraints(knopje1, 1, 3); //zet knopje1 in de 2de kolom en op de 3de rij


        //omzetten van textfields in ints HIER LOOPT HET MIS PEISK
        int aankoop2 = Integer.parseInt(textfield.getText());
        int verkoop2 = Integer.parseInt(textfield2.getText());

        //functie toevoegen aan knopje
        knopje1.setOnAction( e -> calculation(aankoop2, verkoop2));//( e -> calculation(aankoop2, verkoop2));

        //resultaat in een array zetten, zie calculation()
        int[] result = calculation(aankoop2, verkoop2);

        Label labelResultaat = new Label("Winst: " + result[0] ); //result tonen
        GridPane.setConstraints(labelResultaat, 1, 4);

        Label labelResultaat2 = new Label("EA Tax: " + result[1] + " (dit al van de winst afgetrokken.)"); //result tonen
        GridPane.setConstraints(labelResultaat2, 1, 5);

        layout.getChildren().addAll(knopje1, labelAankoop, textfield, labelVerkoop, textfield2, labelResultaat, labelResultaat2);

        Scene scene = new Scene(layout, 400, 200); //instantieer de 'scene', gebruik "layout" als layout, en geef de size van de window
        window.setScene(scene); //gebruik scene genaamd "scene" om als 'scene' te gebruiken
        window.show(); //toon/laat het scherm verschijnen
    }

    private int[] calculation(int aankoop, int verkoop) {

        int eaTax = (verkoop / 100) * 5;
        int winst = (verkoop - eaTax) - aankoop;

        //return winst + eaTax
        return new int[] {winst, eaTax};
    }

}

